# NexOS Supported Targets Specification

| Target ID | SoC / MCU | Architecture | CPU Core | RAM | Flash | Output | Profile | Reference |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `esp32-c6` | ESP32-C6 | RISC-V | RV32IMAC | 512 KB | 4 MB | `.bin` | Advanced | **Reference Platform** |
| `rp2040` | RP2040 | ARM | Dual Cortex-M0+ | 264 KB | 2 MB | `.uf2` | Standard | Supported |
| `pico-w` | RP2040 + CYW43 | ARM | Dual Cortex-M0+ | 264 KB | 2 MB | `.uf2` | Standard | Supported |
| `esp8266` | ESP8266EX | Xtensa | LX106 | 80 KB | 4 MB | `.bin` | Standard | Supported |
| `esp32` | ESP32-D0WD | Xtensa | Dual LX6 | 520 KB | 4 MB | `.bin` | Advanced | Supported |
| `esp32-s3` | ESP32-S3 | Xtensa | Dual LX7 | 512 KB | 8 MB | `.bin` | Advanced | Supported |
| `arduino-avr`| ATmega328P | AVR | 8-bit AVR | 2 KB | 32 KB | `.hex` | Micro | Supported |
| `stm32` | STM32F401/411 | ARM | Cortex-M4 | 128 KB | 512 KB | `.bin` | Advanced | Supported |
| `host` | PC Native | Host | x86_64 | 16 MB | 64 MB | `.exe` | Advanced | **Desktop Simulator** |
