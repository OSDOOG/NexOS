# NexOS Hardware Abstraction Layer (HAL) Guide

The Hardware Abstraction Layer defines uniform, hardware-independent contracts for all microcontroller peripherals.

---

## 1. GPIO (`nex_hal_gpio.h`)
- `nex_gpio_init()`: Initialize pin controller.
- `nex_gpio_mode(pin, mode)`: Configure direction (`NEX_PIN_INPUT`, `NEX_PIN_OUTPUT`, `NEX_PIN_INPUT_PULLUP`, `NEX_PIN_INPUT_PULLDOWN`, `NEX_PIN_OUTPUT_OPENDRAIN`).
- `nex_gpio_write(pin, level)`: Output logic high (`NEX_HIGH`) or low (`NEX_LOW`).
- `nex_gpio_read(pin)`: Read current pin logic level.
- `nex_gpio_toggle(pin)`: Invert pin output state.
- `nex_gpio_attach_interrupt(pin, type, isr, arg)`: Attach edge or level ISR.

---

## 2. UART (`nex_hal_uart.h`)
- `nex_uart_init(port, config)`: Configure baud rate, parity, stop bits, and pin routing.
- `nex_uart_write(port, data, len)`: Transmit byte buffer.
- `nex_uart_read(port, buf, len, received, timeout_ms)`: Receive byte buffer with timeout.
- `nex_uart_putc(port, c)`: Write single character.
- `nex_uart_getc(port)`: Read single character (non-blocking).

---

## 3. SPI (`nex_hal_spi.h`)
- `nex_spi_init(bus, config)`: Configure clock frequency, SPI mode (0-3), bit order, and pins.
- `nex_spi_transfer(bus, tx, rx, len)`: Full-duplex synchronous transfer.
- `nex_spi_write(bus, tx, len)`: Half-duplex write.
- `nex_spi_read(bus, rx, len)`: Half-duplex read.

---

## 4. I2C (`nex_hal_i2c.h`)
- `nex_i2c_init(port, config)`: Set bus speed (100 kHz standard, 400 kHz fast) and pins.
- `nex_i2c_write(port, addr, data, len)`: Master write to 7-bit slave address.
- `nex_i2c_read(port, addr, data, len)`: Master read from 7-bit slave address.
- `nex_i2c_write_reg(port, addr, reg, data, len)`: Write to device register.
- `nex_i2c_read_reg(port, addr, reg, data, len)`: Read from device register.

---

## 5. PWM (`nex_hal_pwm.h`)
- `nex_pwm_init(channel, pin, freq_hz)`: Assign channel to pin with frequency.
- `nex_pwm_set_duty(channel, duty_percent)`: Set 0-100% duty cycle.
- `nex_pwm_start(channel)`: Enable PWM generation.
- `nex_pwm_stop(channel)`: Disable PWM output.

---

## 6. ADC (`nex_hal_adc.h`)
- `nex_adc_init(channel, resolution)`: Set resolution (8, 10, 12 bit).
- `nex_adc_read_raw(channel)`: Raw digit count.
- `nex_adc_read_voltage_mv(channel)`: Calibrated millivolt output.

---

## 7. Timer & SysTick (`nex_hal_timer.h`)
- `nex_hal_systick_init(tick_rate_hz, isr, arg)`: Setup 1ms system heartbeat.
- `nex_hal_get_cycles()`: High-precision cycle counter.
- `nex_hal_delay_us(us)`: Microsecond busy-wait loop.

---

## 8. Network & WiFi (`nex_hal_network.h`)
- `nex_wifi_init()`: Bring up 802.11 MAC/PHY.
- `nex_wifi_connect(config)`: Join SSID with credentials.
- `nex_wifi_disconnect()`: Disconnect from AP.
- `nex_wifi_get_status()`: Status enumeration (`CONNECTED`, `GOT_IP`, `ERROR`).
- `nex_wifi_get_ip_info(info)`: Fetch IP, Netmask, Gateway, DNS.
