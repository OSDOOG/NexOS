# NexOS Application Development Guide

## 1. Writing Your First Application

Applications include `<nexos.h>` and implement `app_main(void)`:

```c
#include <nexos.h>

#define TAG "APP"

void app_main(void) {
    nex_log_info(TAG, "Application booted!");

    if (nex_device_has(NEX_CAP_GPIO)) {
        nex_gpio_mode(15, NEX_PIN_OUTPUT);
        nex_gpio_write(15, NEX_HIGH);
    }

    while (1) {
        nex_delay_ms(1000);
    }
}
```

---

## 2. Using Tasks & Queues

```c
#include <nexos.h>

static nex_queue_handle_t q;

static void worker(void *arg) {
    int val = 42;
    nex_queue_send(q, &val, NEX_WAIT_FOREVER);
}

void app_main(void) {
    nex_queue_create(sizeof(int), 10, &q);
    nex_task_create("worker", worker, NULL, 5, 2048, NULL);

    int received;
    nex_queue_receive(q, &received, NEX_WAIT_FOREVER);
    nex_log_info("APP", "Received: %d", received);
}
```

---

## 3. Querying Hardware Capabilities

Never assume hardware exists on an MCU. Always guard optional hardware:

```c
if (nex_device_has(NEX_CAP_WIFI)) {
    nex_wifi_init();
}

if (nex_device_has(NEX_CAP_DISPLAY)) {
    nex_ssd1306_init(0, 0x3C);
}
```
