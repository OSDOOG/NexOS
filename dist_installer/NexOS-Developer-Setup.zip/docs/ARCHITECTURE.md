# NexOS Architecture Specification v2.0

## 1. Core Architectural Principle

NexOS is a modular, portable, hardware-independent embedded operating system architecture.
The foundational architectural invariant is:

> **NexOS Core MUST NOT depend directly on a specific microcontroller, SoC, board, vendor SDK, or hardware register.**

All hardware interactions are isolated behind standardized interfaces:
- **Hardware Abstraction Layer (HAL)**: Hardware-independent function contracts.
- **Platform Support Packages (PSP)**: Concrete implementations for specific SoCs.
- **Device Drivers**: Standardized `nex_device_*` VFS drivers.

```text
                    NexOS Applications
                            │
                            ▼
                     NexOS API / SDK (<nexos.h>)
                            │
                            ▼
                    NexOS Runtime
                            │
                            ▼
                       NexOS Core
     (Kernel, Scheduler, Memory, Tasks, Sync, IPC, VFS)
                            │
                            ▼
                    Hardware HAL
                            │
             ┌──────────────┼──────────────┐
             ▼              ▼              ▼
          RISC-V          Xtensa          ARM / AVR / Host
     (ESP32-C6 Ref)   (ESP32/ESP8266)  (RP2040, STM32, Arduino)
             │              │              │
          Hardware       Hardware       Hardware
```

---

## 2. Multi-Architecture Support

NexOS abstracts CPU architecture primitives into `arch/include/nex_arch.h`:
- Stack initialization and frame alignment (`nex_arch_stack_init`)
- Global interrupt lock/unlock (`nex_arch_interrupt_disable`, `nex_arch_interrupt_restore`)
- Context switching triggers (`nex_arch_context_switch`)
- First task dispatch (`nex_arch_start_first_task`)

Supported CPU architectures:
- **RISC-V 32-bit (`arch/riscv/`)**: RV32IMC / RV32IMAC (ESP32-C6 reference platform)
- **Xtensa (`arch/xtensa/`)**: Xtensa LX6/LX7/LX106 (ESP32, ESP32-S3, ESP8266)
- **ARM Cortex-M (`arch/arm/`)**: ARMv6-M / ARMv7-M / ARMv8-M (RP2040, STM32)
- **AVR 8-bit (`arch/avr/`)**: ATmega328P (Arduino Uno / Nano)
- **Host Simulation (`arch/host/`)**: x86_64 native simulation on Windows and Linux

---

## 3. Memory Profiles

NexOS adapts to varying microcontroller memory constraints through three standardized profiles:

| Profile | Target Category | RAM Range | Core Features |
| :--- | :--- | :--- | :--- |
| **NexOS Micro** | ATmega328P, Small MCUs | < 16 KB | Cooperative scheduler, static memory pools, basic GPIO/UART/Timer |
| **NexOS Standard** | ESP8266, RP2040, Pico W | 64 - 256 KB | Preemptive multitasking, heap allocator, message queues, VFS, basic networking |
| **NexOS Advanced** | ESP32-C6, ESP32-S3, STM32 | > 256 KB | Full multitasking, dynamic slab/heap, WiFi 6, BLE, security subsystem, OTA |

---

## 4. Capability System

Applications query hardware features dynamically at runtime via `nex_device_has(NEX_CAP_*)`:

```c
if (nex_device_has(NEX_CAP_WIFI)) {
    nex_wifi_init();
    nex_wifi_connect(&cfg);
} else {
    nex_log_info("APP", "No WiFi hardware on target. Using local storage.");
}
```

This guarantees that an application binary or source code can execute gracefully across targets with different peripheral sets without crashing or requiring conditional compilation `#ifdef` cascades in user code.

---

## 5. Binary vs. Source Portability

NexOS maintains **Source-Level Portability**:
The exact same `main.c` file compiles for ESP32-C6, RP2040, ESP8266, Arduino AVR, and Host without modifying application code.
Each target outputs its native executable binary format:
- ESP32-C6: `.bin`
- ESP8266: `.bin`
- RP2040 / Pico: `.uf2`
- Arduino AVR: `.hex`
- STM32: `.bin`
- Host: `.exe` / host binary
