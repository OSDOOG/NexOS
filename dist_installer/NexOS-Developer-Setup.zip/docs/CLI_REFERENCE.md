# NexOS CLI (`nex`) Command Reference

The `nex` command-line interface manages projects, targets, toolchains, compilation, simulation, and diagnostics.

```bash
nex <command> [options]
```

---

## 1. Target Management

### `nex targets`
Displays all registered hardware platforms, their architectures, CPUs, RAM sizes, OS profiles, and binary formats.

```bash
nex targets
```

### `nex target info <target_id>`
Displays detailed platform specifications, pinout mappings, toolchain configurations, and capability bitmasks.

```bash
nex target info esp32-c6
nex target info rp2040
```

---

## 2. Project Creation & Compilation

### `nex create <app_name>`
Scaffolds a new NexOS application with `nexos.json` manifest and starter `main.c`.

```bash
nex create my_sensor
```

### `nex build --target <target_id>`
Compiles application source for the chosen hardware target.

```bash
nex build --target esp32-c6
nex build --target rp2040
nex build --target arduino-avr
```

### `nex clean`
Cleans the `build/` artifact directory.

---

## 3. Host Simulator & Flashing

### `nex run --target host`
Compiles and executes the application natively on Windows using the Host Simulation Platform.

```bash
nex run --target host
```

### `nex flash --target <target_id> [--port <port>]`
Flashes the compiled binary onto physical hardware using the target's configured flashing utility (`esptool.py`, `picotool`, `avrdude`, `st-flash`).

```bash
nex flash --target esp32-c6 --port COM3
```

### `nex monitor [--port <port>] [--baud <baud>]`
Opens serial terminal monitor.

```bash
nex monitor --port COM3 --baud 115200
```

---

## 4. Diagnostics & Toolchains

### `nex doctor`
Performs comprehensive diagnostic inspection of Python, Node, Git, target packages, Core header integrity, and cross-compilers.

```bash
nex doctor
```

### `nex toolchain list`
Lists all detected and missing cross-compilers (`riscv-none-elf-gcc`, `xtensa-esp32-elf-gcc`, `arm-none-eabi-gcc`, `avr-gcc`).

```bash
nex toolchain list
```
