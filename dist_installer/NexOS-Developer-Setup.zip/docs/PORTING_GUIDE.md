# Porting Guide: How to Add a New Target to NexOS

Adding a new microcontroller target to NexOS requires **zero modifications to the NexOS Core**.
Follow this standardized 10-step process:

---

## Step 1: Define CPU Architecture

If the target's CPU architecture is already supported (RISC-V, Xtensa, ARM Cortex-M, AVR), skip to Step 2.
Otherwise, create a new architecture directory under `arch/<new_arch>/`:
- Implement `nex_arch_init()`
- Implement `nex_arch_interrupt_disable()` and `nex_arch_interrupt_restore()`
- Implement `nex_arch_stack_init()` for context stack frame layout
- Implement `nex_arch_context_switch()`

---

## Step 2: Create Target Definition

Create `targets/<target_id>/target.json`:

```json
{
    "name": "my-target",
    "display_name": "Vendor Board Name",
    "architecture": "arm",
    "cpu": "cortex-m4",
    "clock_mhz": 120,
    "ram_bytes": 131072,
    "flash_bytes": 524288,
    "profile": "standard",
    "toolchain": {
        "prefix": "arm-none-eabi-",
        "compiler": "arm-none-eabi-gcc",
        "cflags": "-mcpu=cortex-m4 -mthumb -O2 -ffunction-sections -fdata-sections",
        "ldflags": "-T platforms/my-target/linker/target.ld -Wl,--gc-sections"
    },
    "output_format": "bin",
    "flash_tool": "openocd",
    "flash_args": "-f board.cfg -c 'program {output_file} verify reset exit'",
    "capabilities": ["GPIO", "UART", "SPI", "I2C", "TIMER"]
}
```

---

## Step 3: Implement Platform Support Package (PSP)

Create `platforms/<target_id>/`:
1. `platforms/<target_id>/platform.json`: Platform metadata.
2. `platforms/<target_id>/<target_id>_hal_gpio.c`: GPIO read, write, mode configurations.
3. `platforms/<target_id>/<target_id>_hal_uart.c`: Serial transmit, receive, flush.
4. `platforms/<target_id>/<target_id>_hal_timer.c`: SysTick interrupt timer (1000 Hz).
5. `platforms/<target_id>/<target_id>_boot.c`: Platform startup and vector entry.

---

## Step 4: Add Linker Configuration

Place the memory map and sections in `platforms/<target_id>/linker/<target_id>.ld`:
- Define `MEMORY` regions (Flash, RAM, vector tables)
- Set entry symbol to `nex_platform_boot`

---

## Step 5: Implement Platform Boot Sequence

In `platforms/<target_id>/<target_id>_boot.c`:
```c
#include <nexos.h>

const char *g_nex_target_name = "my-target";
const char *g_nex_arch_name = "arm-cortex-m4";
nex_profile_t g_nex_system_profile = NEX_PROFILE_STANDARD;

#define PLATFORM_HEAP_SIZE (64 * 1024)
static uint8_t s_heap[PLATFORM_HEAP_SIZE];

extern void app_main(void);

void nex_platform_boot(void) {
    /* 1. Register target capabilities */
    nex_capability_register(NEX_CAP_GPIO | NEX_CAP_UART | NEX_CAP_TIMER);

    /* 2. Initialize memory heap */
    nex_memory_init(s_heap, PLATFORM_HEAP_SIZE);

    /* 3. Initialize hardware HAL */
    nex_gpio_init();
    nex_uart_init(0, NULL);

    /* 4. Bootstrap NexOS Core */
    nex_core_init();

    /* 5. Create app task & start scheduler */
    nex_task_create("app_main", (nex_task_entry_t)app_main, NULL, 4, 2048, NULL);
    nex_core_start();
}
```

---

## Step 6: Verify Target with NexOS CLI

Run:
```bash
nex targets
```
Verify that `my-target` is listed with its architecture, CPU, and RAM.

---

## Step 7: Inspect Target Information

Run:
```bash
nex target info my-target
```
Check that all capabilities, clock speeds, and compiler configurations are reported accurately.

---

## Step 8: Build Sample Application

Run:
```bash
nex build --target my-target
```
The build system will invoke the cross-compiler and link the application using your platform linker script.

---

## Step 9: Run Automated Architecture Verification

Run:
```bash
python tests/run_all_tests.py
```
Ensure 100% compliance with zero architectural leakage.

---

## Step 10: Open NexOS Developer Studio

Run:
```bash
python nexos-developer/server.py
```
Your target will automatically appear in the Target Selector dropdown with live capability tags!
