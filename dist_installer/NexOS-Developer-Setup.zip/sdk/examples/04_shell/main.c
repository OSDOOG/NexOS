/**
 * @file main.c
 * @brief NexOS Example 04: Interactive System Console Shell
 */

#include "nexos.h"
#include <stdio.h>
#include <string.h>

#define TAG "SHELL"

static void shell_exec_cmd(const char *cmd) {
    if (strcmp(cmd, "help") == 0) {
        nex_log_info(TAG, "Commands: help, info, caps, mem, reboot");
    } else if (strcmp(cmd, "info") == 0) {
        nex_system_info_t info;
        nex_core_get_info(&info);
        nex_log_info(TAG, "Target: %s, Arch: %s, Profile: %d", info.target_name, info.arch_name, info.profile);
    } else if (strcmp(cmd, "caps") == 0) {
        nex_capability_dump();
    } else if (strcmp(cmd, "mem") == 0) {
        nex_mem_stats_t stats;
        nex_memory_get_stats(&stats);
        nex_log_info(TAG, "Memory: total=%u, free=%u, min_free=%u", (unsigned int)stats.total_bytes, (unsigned int)stats.free_bytes, (unsigned int)stats.min_free_bytes);
    } else if (strcmp(cmd, "reboot") == 0) {
        nex_log_warn(TAG, "Rebooting target...");
        nex_power_restart();
    } else {
        nex_log_warn(TAG, "Unknown command: '%s'. Type 'help' for available commands.", cmd);
    }
}

void app_main(void) {
    nex_log_info(TAG, "NexOS Interactive Shell v2.0 ready");
    shell_exec_cmd("info");
    shell_exec_cmd("caps");
    shell_exec_cmd("mem");
    nex_log_info(TAG, "Shell initialization complete.");
}
